package homePageTestCases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import setup.LogIn;

import webPages.AddReleases;
import webPages.EditReleases;
import webPages.ReleasesPage;

public class TestCases {

	@Test(priority = 1)
	public void openBrowser() {
		try {
			LogIn.loadDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(priority = 2)
	public void browseUrl() {
		LogIn.getURL();
	}

	@Test(priority = 3)
	public void Login() {
		LogIn.getCredentials();
	}

	@Test(priority = 4)
	public void Mainpage() {
		LogIn.getMainPage();
	}

	@Test(priority = 5)
	public void openM() {
		LogIn.openModule();
	}

	@Test(priority = 6)
	public void ReleaseFunc() throws InterruptedException {
		ReleasesPage func = LogIn.nextPage();
		func.addRelease();
		func.exportButton();
		Thread.sleep(3000);
		func.clearAllFilters();
		Thread.sleep(3000);
		func.multipleSort();
		Thread.sleep(3000);
		func.downloadAttachments();
		Thread.sleep(3000);
		func.searchBoxFilter();
		Thread.sleep(3000);
		func.advancedFilter();
		Thread.sleep(3000);
		func.tableViewFilter();
		Thread.sleep(3000);

	}

	@Test(priority = 7)
	public void SaveButtonWithValidData() {
		AddReleases add = ReleasesPage.nextPage();
		// String[] data=ReadTestData.readTestData("ValidData");
		// String[] errordata=ReadTestData.readTestData("Errors");
		add.addResources();
		//retryingFindClick(By.xpath("AddReleaseBtn"));
		add.switchFrame();
		add.nameTxtBox("data");
		add.descTxtBox("test");
		add.relType("Major");
		add.startDate("18-May-2021");
		add.endDate("01-Jun-2021");
		add.selectPriority("Medium");
		add.selectTechnology("--None--");
		add.setSize("15");
		add.selectPerson("Gayatri Gangireddy");
		add.relNum("453");
		add.setCapacity("32");
		add.clickOnSave();
		//add.switchFrame();
		
		add.clickOnReturn();
		// add.switchFrame();
		// add.parentFrame();
		// add.valid();
		// add.clickOnReturn();

		//add.parentFrame();
		System.out.println("TC 7 was passed");
	}

	//@Test(priority = 8 )
	public void SaveButtonWithInValidData() {
		AddReleases invalid = ReleasesPage.nextPage();
		//invalid.parentFrame();
		//System.out.println("Frame switched");
		invalid.addResources();
		System.out.println("Plus clicked");
		invalid.switchFrame();
		System.out.println("Frame switched again");
		invalid.nameTxtBox("Hi");
		System.out.println("name printed");
		invalid.descTxtBox("test with invalid data");
		invalid.relType("--None--");
		invalid.startDate("18-Feb-2021");
		invalid.endDate("01-Feb-2021");
		invalid.selectPriority("--None--");
		invalid.selectTechnology("--None--");
		invalid.setSize("-1");
		invalid.selectPerson("--None--");
		invalid.relNum("99999999999999999999999999999999999");
		invalid.setCapacity("-43");
		invalid.clickOnSave();
		invalid.clickOnReturn();
		//invalid.parentFrame();
		System.out.println("TC 8 was passed");

	}

	//@Test(priority = 9)
	public void SaveButtonWithMandatoryData() {
		AddReleases mand = ReleasesPage.nextPage();
		// String[] data=ReadTestData.readTestData("MandatoryData");
		// String[] errordata=ReadTestData.readTestData("Errors");
		mand.addResources();
		mand.switchFrame();
		mand.nameTxtBox("data");
		mand.relType("Major");
		mand.startDate("20-May-2021");
		mand.endDate("13-Jun-2021");
		mand.selectPriority("Medium");
		mand.selectTechnology("--None--");
		mand.clickOnSave();
		mand.clickOnReturn();
		//mand.parentFrame();
		System.out.println("TC 9 was passed");

		//mand.parentFrame();

	}

	//@Test(priority = 10)
	public void ValidateTheFunctionalityOfReturnButtonWithFormValues() {
		AddReleases rtn = ReleasesPage.nextPage();
		rtn.addResources();
		rtn.switchFrame();
		rtn.nameTxtBox("data");
		rtn.descTxtBox("test");
		rtn.relType("Major");
		rtn.startDate("13-May-2021");
		rtn.endDate("13-Jun-2021");
		rtn.selectPriority("Medium");
		rtn.selectTechnology("--None--");
		rtn.setSize("15");
		rtn.selectPerson("Gayatri Gangireddy");
		rtn.relNum("500");
		rtn.setCapacity("64");
		rtn.clickOnReturn();
		//rtn.parentFrame();
		System.out.println("TC 10 was passed");

	}

	//@Test(priority = 11, dependsOnMethods = { "ValidateTheFunctionalityOfReturnButtonWithFormValues" })
	public void ValidateTheFunctionalityOfReturnButtonWithNoFormValues() {
		AddReleases add = ReleasesPage.nextPage();

		add.switchFrame();
		add.Return();
		//add.parentFrame();
	}

	//@Test(priority = 12, dependsOnMethods = { "ValidateTheFunctionalityOfReturnButtonWithNoFormValues" })

	public void ReturnButtonWithoutModificationInForm() {
		EditReleases edit = AddReleases.nextPage();

		edit.OpenRelease("REL2"); // edit.grid(); //edit.saveButton();
		edit.returnBackAfterCreation();
		edit.parentFrame();

	}

	@Test(priority = 13)
	public void close() {
		LogIn.closeBrowser();
	}

	// @Test(priority = 13 ,
	// dependsOnMethods={"ReturnButtonWithoutModificationInForm"})
	public void saveButtonWithModificationInForm() {
		EditReleases edit = AddReleases.nextPage();
		// String[] data=ReadTestData.readTestData("DataModify");
		edit.parentFrame();
		edit.OpenRelease("REL2");
		// edit.grid1();
		edit.switchFrame();
		edit.getName().click();
		edit.getName().clear();
		edit.getName().sendKeys("testmodified");
		// edit.parentFrame();
		// edit.saveButton();
		edit.returnBackAfterCreation();

	}

	// @Test(priority = 14 , dependsOnMethods={"saveButtonWithModificationInForm"})
	public void returnPageOnEditReleasePage() {
		EditReleases edit = AddReleases.nextPage();
		// String[] data=ReadTestData.readTestData("DataModify");
		edit.OpenRelease("REL2");
		edit.returnBackAfterCreation();

	}

}
