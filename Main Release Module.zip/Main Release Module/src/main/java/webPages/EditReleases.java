package webPages;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import setup.LoadProperties;

public class EditReleases {

	static WebDriver driver;
	Properties prop;
	WebDriverWait wait;
	String filePath = System.getProperty("user.dir") + "\\mainResources\\properties\\config.properties";

	public EditReleases() {

	}

	// Receiving the driver instance using constructor
	public EditReleases(WebDriver driver) {
		EditReleases.driver = driver;
		prop = LoadProperties.readFile(filePath);
		wait = new WebDriverWait(driver, 10);

	}

	// getting into frame
	public void switchFrame() {
		driver.switchTo().frame(getElement(getPropertyValue("middleframe")));
	}

	// coming back from iframe
	public void parentFrame() {
		driver.switchTo().defaultContent();
	}

	// Getting the values for given key from property file
	public String getPropertyValue(String key) {
		return LoadProperties.readProperty(key);
	}

	// locating the element
	public WebElement getElement(String path) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(path))));
		return driver.findElement(By.xpath(path));
	}

	// Open Already created Release
	public void OpenRelease(String relitem) {

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// String value = "Giri";
		WebElement search = getElement(getPropertyValue("searchinputbox"));
		search.click();
		search.clear();
		search.sendKeys(relitem);
		getElement(getPropertyValue("searchbutton")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();

		}
		driver.findElement(By.xpath("//div[text()='REL2']")).click();
		wait.until(ExpectedConditions.titleContains("Release : Details"));
		/*
		 * WebElement
		 * click3=driver.findElement(By.xpath("//*[@id=\"searchTextBox-inputEl\"]")); //
		 * clicking on search field under monitor click3.click(); click3.clear();
		 * click3.sendKeys(relitem);
		 * 
		 * 
		 * 
		 * driver.findElement(By.xpath("//*[@id=\"searchButton-btnIconEl\"]")).click();
		 */

		/*
		 * List<WebElement> list =
		 * driver.findElements(By.xpath(getPropertyValue("ListofItems")));
		 * 
		 * for (WebElement item : list) { String Name = item.getText(); if
		 * (Name.equals(relitem)) { item.click(); break; } }
		 */

	}

	/*
	 * public void grid() { driver.findElement(By.xpath(
	 * "//*[@id=\"gridview-1388-record-1213\"]/tbody/tr/td[3]/div")).click();
	 * wait.until(ExpectedConditions.titleContains("Release : Details")); }
	 * 
	 * public void grid1() {
	 * driver.findElement(By.xpath("//div[text()='REL201']")).click(); wait.
	 * until(ExpectedConditions.titleContains("Release : Details")); }
	 */
	// locating the release id
	public WebElement getReleaseId() {
		return getElement(getPropertyValue("ReleaseId"));
	}

	// locating name input box
	public WebElement getName() {
		return getElement(getPropertyValue("NameTxtBox"));
	}

	// locating description input box
	public WebElement getDescription() {
		return getElement(getPropertyValue("DescriptionTxtBox"));
	}

	// Select approximate release type
	public void relType(String value, String path) {

		Select s1 = new Select(getElement(path));

		s1.selectByVisibleText(value);
	}

	// locating start date field
	public WebElement getStartDate() {
		return getElement(getPropertyValue("Startdate"));
	}

	// locating end date field
	public WebElement getEndDate() {
		return getElement(getPropertyValue("Enddate"));
	}

	// select the priority
	public void selectPriority(String value, String path) {

		Select s2 = new Select(getElement(path));
		s2.selectByVisibleText(value);
	}

	// select technology used
	public void selectTechnology(String value, String path) {

		Select s3 = new Select(getElement(path));
		s3.selectByVisibleText(value);
	}

	public WebElement setSize() {
		// Enter the size
		return getElement(getPropertyValue("SizeTxt"));

	}

	public void selectPerson(String value, String path) {
		// Select the person from the dropdown
		Select s4 = new Select(getElement(path));
		s4.selectByVisibleText(value);
	}

	public WebElement relNum() {
		// Enter the release number

		return getElement(getPropertyValue("ReleaseNum"));
	}

	public WebElement setCapacity() {
		// Enter the capacity

		return getElement(getPropertyValue("CapacityTxt"));
	}

	// edit the form
	public void EditForm() {

		switchFrame();
		getName().clear();
		getName().sendKeys("TestEdited");
		getDescription().clear();
		getDescription().sendKeys("Created for testing to edit details");

		relType("patch", getPropertyValue("releaseType"));
		getStartDate().clear();
		getStartDate().sendKeys("19-Feb-2021");
		getEndDate().clear();
		getEndDate().sendKeys("02-Mar-2021");
		selectPriority("Medium", getPropertyValue("PriorityPath"));
		selectTechnology("ABAP", getPropertyValue("techPath"));
		setSize().clear();
		setSize().sendKeys("12");
		selectPerson("Mohana Krishna Priya Vinnakota", getPropertyValue("RespPath"));
		relNum().sendKeys("422");
		setCapacity().sendKeys("44");
		parentFrame();
	}

	// locating and clicking on save button to save release
	public void saveButton() {

		wait.until(ExpectedConditions.titleContains("Release : Details "));
		switchFrame();
		getElement(getPropertyValue("SaveBtn")).click();

		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());

				alert.accept();
			}
		} catch (Exception e) {
		}
		parentFrame();

	}

	// locating save and add new button to save release and open new form
	public void saveAndAddNew() {

		wait.until(ExpectedConditions.titleContains("Release Details :"));
		switchFrame();
		getElement(getPropertyValue("saveAddNew")).click();

		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}
		parentFrame();
	}

	// locating the return button to go back
	public void returnBackAfterCreation() {

		wait.until(ExpectedConditions.titleContains("Release : Details"));
		switchFrame();
		getElement(getPropertyValue("ReturnBtn")).click();

		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}
		parentFrame();

	}

	

}
