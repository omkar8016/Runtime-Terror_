package webPages;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import setup.LoadProperties;

public class ReleasesPage {

	static WebDriver driver;
	Properties prop;
	Actions action;
	String currentWindow;
	WebDriverWait wait;
	String filePath = System.getProperty("user.dir") + "\\mainResources\\properties\\config.properties";

	public ReleasesPage() {

	}

	// Receiving the driver instance using constructor
	public ReleasesPage(WebDriver driver) {
		ReleasesPage.driver = driver;
		prop = LoadProperties.readFile(filePath);
		action = new Actions(driver);
		wait = new WebDriverWait(driver, 10);

	}

	// Getting the values for given key from property file
	public String getPropertyValue(String key) {
		return LoadProperties.readProperty(key);
	}

	// locating the element
	public WebElement getElement(String path) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(path))));
		return driver.findElement(By.xpath(path));

	}

	// getting into frame
	public void switchFrame() {
		driver.switchTo().frame(getElement(getPropertyValue("middleframe")));
	}

	// coming back from iframe
	public void parentFrame() {
		driver.switchTo().defaultContent();
	}

	
	
	//Checking functionality of Add Release button
	public void addRelease() throws InterruptedException {
	  getElement(getPropertyValue("AddReleaseBtn")).click();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  //driver.switchTo().frame(driver.findElement(By.id("contentframe")));
	  switchFrame();
	  Thread.sleep(10000);
	  getElement(getPropertyValue("ReturnBtn")).click();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  
	  //System.out.println("Functionality of Add Release: PASSED");
	  }
	public void exportButton() {
		currentWindow = driver.getWindowHandle();
		getElement(getPropertyValue("exportsrelease")).click();
		for (String windows : driver.getWindowHandles()) {
			driver.switchTo().window(windows);

		}
		getElement(getPropertyValue("exportbackbutton")).click();
		driver.switchTo().window(currentWindow);
		//System.out.println("Functionality of Export Button: PASSED");

	}

	 
	//Checking functionality of Clear all filter

	public void clearAllFilters() {
		getElement(getPropertyValue("clearallfilter")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//System.out.println("Functionality of Clear All Filters: PASSED");

	}

	//Checking functionality of Multiple sort
	public void multipleSort() {
		getElement(getPropertyValue("multiplesort")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getElement(getPropertyValue("goformultiplesort")).click();
		//System.out.println("Functionality of Multiple Sort: PASSED");
	}

	//Checking functionality of Download Attachments
	public String downloadAttachments() {
		getElement(getPropertyValue("downloadattachments")).click();
		//System.out.println("Functionality of Download Attachments: PASSED");
		Alert downloadAlert = driver.switchTo().alert();
		String alertMessage = downloadAlert.getText();
		downloadAlert.accept();
		return alertMessage;
	}
	//Checking functionality of search box filter

	public void searchBoxFilter() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String value = "Buddhaghosh";
		WebElement search = getElement(getPropertyValue("searchinputbox"));
		search.click();
		search.sendKeys(value);
		getElement(getPropertyValue("searchbutton")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();

		}
		//System.out.println("Functionality of Search Box Filter: PASSED");
		WebElement result = getElement(getPropertyValue("clearallfilter"));
		result.click();
	}

	//Checking functionality of advanced filter
	public void advancedFilter() {
		getElement(getPropertyValue("advancedfilter")).click();

		//System.out.println("Functionality of Advanced Filter: PASSED");

	}

	//Checking functionality of tableview filter
	public void tableViewFilter() {
		getElement(getPropertyValue("tableview")).click();
		getElement(getPropertyValue("tableviewApply")).click();
		
		//System.out.println("Functionality of Table View Filter: PASSED");
		//driver.findElement(By.xpath("//span[@id='KEY_BUTTON_Add-btnIconEl']")).click();
	}
	// navigating to next page
	public static AddReleases nextPage() {
		return PageFactory.initElements(driver, AddReleases.class);
	}

}
