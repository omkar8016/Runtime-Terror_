package setup;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.annotations.Test;

import webPages.ReleasesPage;

public class LogIn {

	public static WebDriver driver;
	public static String baseUrl;
	static WebElement yes;
	WebDriverWait wait;

	// driver setup
	public static void loadDriver() throws Exception {

		String driverkey = LoadProperties.readProperty("driverkey");
		String driverval = LoadProperties.readProperty("driverval");

		System.setProperty(driverkey, driverval);

		if (driverval.contains("chrome")) {
			ChromeOptions co = new ChromeOptions();

			co.addArguments("--disable-notifications");

			// WebDriver driver = new ChromeDriver(co);
			driver = new ChromeDriver(co);
		} else if (driverval.contains("gecko")) {
			FirefoxOptions fo = new FirefoxOptions();

			fo.addPreference("dom.webnotifications.enabled", false);

			driver = new FirefoxDriver();

		}

		else {
			throw new Exception("Web Driver not supported");
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	// Getting the values for given key from property file
	public String getPropertyValue(String key) {
		return LoadProperties.readProperty(key);
	}

	// locating the element
	public WebElement getElement(String path) {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(path))));
		return driver.findElement(By.xpath(path));

	}

	// browse URL
	public static void getURL() {
		driver.get(LoadProperties.readProperty("baseurl"));

	}

	// enter credentials
	public static void getCredentials() {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.findElement(By.id("i0116")).sendKeys(LoadProperties.readProperty("userName")); // enter username
		driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click(); // click next

		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//*[@id=\"i0118\"]")).sendKeys(LoadProperties.readProperty("password")); 
																												
		//driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click(); // click on sign in

		/*
		 * driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		 * driver.findElement(By.xpath("//*[@id=\"idTxtBx_SAOTCC_OTC\"]")).sendKeys(
		 * LoadProperties.readProperty("OTP")); // enter otp try { Thread.sleep(5000); }
		 * catch (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 * driver.findElement(By.xpath("//*[@id=\"idSubmit_SAOTCC_Continue\"]")).click()
		 * ; // click on verify
		 */
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 120);
		 * 
		 * yes = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
		 * "//*[@id='idSIButton9']"))); // click on // stay yes.click();
		 */

	}

	// navigate to main page
	public static void getMainPage() {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='navbar']/div[3]/div[1]")).click(); // click on side bar

		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"projectIcon\"]/ul/li[1]/a")).click(); // clicking on CFO_Onsite Project
																						// release

	}

	// *[@id="ext-element-1"]

	// navigate to Release page
	public static void openModule() {

		// using Javascript executor to click on further elements
		JavascriptExecutor js = (JavascriptExecutor) driver;

		WebElement click = driver.findElement(By.xpath("//*[@id='LOCK_Plan']"));
		js.executeScript("arguments[0].click()", click); // clicking on monitor

		WebElement click1 = driver.findElement(By.xpath("//*[@id='LOCK_Releases']"));
		js.executeScript("arguments[0].click()", click1);

		// WebElement click2 =
		// driver.findElement(By.xpath("//*[@id=\"KEY_BUTTON_Add-btnWrap\"]")); // click
		// on "add issues button"
		// js.executeScript("arguments[0].click()", click2);

	}

	public static void closeBrowser() {
		driver.quit();
	}

	public static ReleasesPage nextPage() {
		return PageFactory.initElements(driver, ReleasesPage.class);
	}

}
