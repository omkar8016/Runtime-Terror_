package TestCases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Utilities.ReadUserDetails;
import Utilities.WriteHotelDetails;
import basePackage.DriverSetup;
import pages.HotelDetails;
import pages.SearchDestination;
import pages.SetDates;

public class CalculateTripCost {
	 public static WebDriver driver;

	//public static WebDriver driver;

	static By searchResult = By.xpath("//a[normalize-space()='Elegant Cosy Conquest']");
	static By hotelName = By.cssSelector("._2K0y-IXo");
	static By holidayHomes = By.partialLinkText("Holiday Homes");
	static By sortRate = By.xpath("(//div[@class=\"_1NO-LVmX\"])[3]");
	static By travellerRating = By.xpath("//span[contains(text(),'Traveller Rating')]");
	static By guest = By.className("_2uJXqhFj");
	static By guestAdd = By.xpath("(//span[@class=\"ui_icon plus HxR7KwIa\"])[2]");
	static By apply = By.xpath("(//button[@class=\"ui_button primary fullwidth\"])[2]");
	static By animities = By.cssSelector(
			"#component_2 > div > div.delineation > div > div._3gJTNtfw > div._3PlsTJV5 > div._3b6IjZ6r > div > div > div:nth-child(12) > div._3kI1z_wP > span._3ncH7U-p");
	static By liftFacility = By.xpath("//div[contains(text(),'Elevator/Lift access')]");
	static By sortByValues = By.xpath("//*[@id=\"component_2\"]/div/div[3]/div/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div/span");

	@BeforeSuite(groups = { "Basics", "SmokeTest" })
	// This function is used to initialize the drivers.
	public void SetDrivers() throws IOException {

		// Creating an object of DriverSetup class to use the different drivers of
		// different browsers.
	//	DriverSetup obj = new DriverSetup();

		// Setting up the driver for chosen browser from properties file
		if (getPropertyFile("Browser").equalsIgnoreCase("Chrome")) {

			driver = DriverSetup.setupChromeDriver();
			driver.manage().window().maximize(); // maximizes window
			driver.manage().deleteAllCookies(); // delete cookies

		}

		else if (getPropertyFile("Browser").equalsIgnoreCase("FireFox")) {

			driver = DriverSetup.setupFireFoxDriver();
			driver.manage().window().maximize(); // maximizes window
			driver.manage().deleteAllCookies(); // delete cookies

		} else if (getPropertyFile("Browser").equalsIgnoreCase("Edge")) {

			driver = DriverSetup.setupEdgeDriver();
			driver.manage().window().maximize(); // maximizes window
			driver.manage().deleteAllCookies(); // delete cookies

		} else {

			driver = DriverSetup.setupChromeDriver();
			driver.manage().window().maximize(); // maximizes window
			driver.manage().deleteAllCookies(); // delete cookies

		}

	}

	// This function is used to read the property file
	public static String getPropertyFile(String prop_name) throws IOException {

		Properties prop = new Properties();
		// Importing the config file
		InputStream readFile = new FileInputStream(System.getProperty("user.dir") + "\\Config.properties");
		// Loading the config file
		prop.load(readFile);
		return prop.getProperty(prop_name);

	}

	// This function is used to take screenshots
	public void TakeScreenShot(String Name) {

		// Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		// Call getScreenshotAs method to create image file
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		// Move image file to new destination
		// String path = System.getProperty("user.dir");
		File DestFile = new File(System.getProperty("user.dir") + "\\ScreenShots\\" + Name + ".png");
		// Copy file at destination
		try {
			FileUtils.copyFile(SrcFile, DestFile);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 0, groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// This function to to set the url
	public void SetUrl() throws IOException {
		String Base_Url = getPropertyFile("Url");
		driver.navigate().to(Base_Url);
		// This code is used to maximize the window
		driver.manage().window().maximize();
		// To take a screenshot of the Home Page
		TakeScreenShot("HomePage");

	}

	@Test(priority = 1, groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// This function is to search the Destination
	public void SearchDestination() throws IOException, InterruptedException {

		// Creating an object of the Input Excel Class
		ReadUserDetails Excel_input = new ReadUserDetails();
		String destination = Excel_input.ReadDestination();

		// Creating an object of SearchDestination to search our desired Destination
		SearchDestination Search = new SearchDestination(driver);
		Search.SearchDest(driver, destination);

		// Printing to console
		System.out.println("Destination is: " + destination + "\n");

	}

	@Test(priority = 2, dependsOnMethods = "SearchDestination", groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// To Click on the Holiday Homes Button
	public void ClickHolidayHomesButton() throws InterruptedException {
		// We wait for the element to appear until the page loads
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.visibilityOfElementLocated(holidayHomes));
		wait.until(ExpectedConditions.elementToBeClickable(holidayHomes));

		// Click on the holiday homes button
		WebElement Holiday_homes = driver.findElement(holidayHomes);
		Actions actions = new Actions(driver);
		// To take a screenshot of Holiday Homes button
		TakeScreenShot("HolidayHomes");

		// Clicking on Holiday Homes
		actions.moveToElement(Holiday_homes).doubleClick().build().perform();

	}

	@Test(priority = 3, groups = { "Hotels", "RegressionTest" })
	// To set the Check-in Dates
	public void SetCheckInDate() throws IOException, InterruptedException {

		// Creating an object of the Input Excel Class
		ReadUserDetails Excel_input = new ReadUserDetails();
		String[] Dates = new String[1];
		Dates = Excel_input.ReadDates();
		// Selecting the Check in and Check out Date from the Array Dates
		String check_in = Dates[0];

		// Creating an object of SetDates, to set the check-in and check-out dates
		SetDates setDate = new SetDates();
		setDate.SetCheckInDate(driver, check_in);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Printing to console
		System.out.println("Check-in Date is : " + check_in);

	}

	@Test(priority = 4, groups = { "Hotels", "RegressionTest" })
	// To set the Check-out Dates
	public void SetCheckOutDate() throws IOException, InterruptedException {

		// Creating an object of the Input Excel Class
		ReadUserDetails Excel_input = new ReadUserDetails();
		String[] Dates = new String[1];
		Dates = Excel_input.ReadDates();
		// Selecting the Check in and Check out Date from the Array Dates

		String check_out = Dates[1];
		// Creating an object of SetDates, to set the check-in and check-out dates
		SetDates setDate = new SetDates();
		setDate.SetCheckOutDate(driver, check_out);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Printing to console
		System.out.println("Check-out Date is: " + check_out);

	}

	@Test(priority = 5, groups = { "Hotels", "RegressionTest" })
	// To select the Number of Guests
	public void NoOfGuests() throws Exception {

		// Wait for the page to load
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Clicking on Guests
		driver.findElement(guest).click();

		// Creating an object of the Input Excel Class
		ReadUserDetails Excel_input = new ReadUserDetails();
		int number_of_guests = Excel_input.ReadNumberOfGuest();

		// as default value is 2, so we will increment till the amount of guests we need
		for (int defvalue = 2; defvalue < number_of_guests; defvalue++) {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			// driver.findElement(By.cssSelector(getPropertyFile("Guest_add"))).click();
			driver.findElement(guestAdd).click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}

		// To take a screenshot
		TakeScreenShot("NoOfGuest");

		driver.findElement(apply).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Printing to console
		System.out.println("Number of guests to book Holiday Homes is :  " + number_of_guests + "\n");

	}

	@Test(priority = 6, groups = { "Hotels", "RegressionTest" })
	// To sort the results by Traveler Ratings
	public void SortByValues() throws Exception {
		//driver.get("https://www.tripadvisor.in/VacationRentals-g294207-Reviews-Nairobi-Vacation_Rentals.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// We check if the Traveller Rating Dropdown is present or it is clickable
		WebDriverWait wait = new WebDriverWait(driver, 60);

		wait.until(ExpectedConditions.visibilityOfElementLocated(sortRate));
		wait.until(ExpectedConditions.elementToBeClickable(sortRate));
		Thread.sleep(5000);
		// Verifying database values of sortby
		driver.findElement(sortRate).click();

		List<WebElement> list = driver.findElements(sortByValues);
		for (int i = 0; i < list.size(); i++) {
			WebElement element = list.get(i);
			String value = element.getAttribute("innerHTMl");
			System.out.println("Values in sort by are: " + value);
		}
		// To take a screenshot
		TakeScreenShot("Sort By Values");

	}

	@Test(priority = 7, groups = { "Hotels", "RegressionTest" })
	// To sort the results by Traveler Ratings
	public void SortByTraveller() throws Exception {
		// Sorting according to Traveller Rating Sort
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(travellerRating).click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// To take a screenshot
		TakeScreenShot("Traveler Sort");

	}

	@Test(priority = 8, groups = { "Hotels", "RegressionTest" })
	// To click on LiftAaccess
	public void ShowMore() throws Exception {

		// Selecting Elevator/Lift access in amenities
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1100)");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Clicking on dropdown in Amenities to select Lift/Elevator access
		driver.findElement(animities).click();
		TakeScreenShot("Show More");

	}

	@Test(priority = 9, groups = { "Hotels", "RegressionTest" })
	// To click on LiftAaccess
	public void LiftAccess() throws Exception {
		driver.findElement(liftFacility).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// To take a screenshot
		TakeScreenShot("Lift Access");

		js.executeScript("window.scrollBy(0,-900)");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// To sync the code
		Thread.sleep(1000);
	}

	@Test(priority = 10, groups = { "Hotels", "RegressionTest" })
	// To get all the required details of the top-3 result hotels
	public void HotelDetails() throws IOException, InterruptedException {

		// We wait for the elements to load and to be clickable
		// driver.findElements(By.cssSelector("._2K0y-IXo")).get(0);
		WebElement Hotel_name = driver.findElements(hotelName).get(0);
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.visibilityOfElementLocated(searchResult));
		wait.until(ExpectedConditions.elementToBeClickable(searchResult));

		// To take a screenshot
		TakeScreenShot("Search Results");

		// Creating an object of GetHotelDetails to fetch the name, charges per night
		// and total cost
		HotelDetails GetHotels = new HotelDetails(driver);

		// To store the Hotel Names
		String[] name = new String[3];
		name = GetHotels.GetHotelName(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// To store the total amount
		String[] total_amount = new String[3];
		total_amount = GetHotels.GetHotelTotalCharge(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// To store the charges per night
		String[] charges_pernight = new String[3];
		charges_pernight = GetHotels.GetChargesPerNight(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Creating an object of WriteHotelDetails to send the above data to excel
		WriteHotelDetails SendToExcel = new WriteHotelDetails();
		SendToExcel.WriteToExcel(name, total_amount, charges_pernight);

	}

	@Test(priority = 11, groups = { "Hotels", "RegressionTest" })
	// To get the screenshots of the 3 respective Hotels
	public void GetHotelScreenShots() throws IOException, InterruptedException {

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Creating an object of GetHotelDetails to fetch the Hrefs of the Hotels
		HotelDetails GetHref = new HotelDetails(driver);

		// To store the Hrefs
		String[] Hotel_Hrefs = new String[3];
		Hotel_Hrefs = GetHref.GetHotelLinks(driver);
		System.out.println("Size is :" + Hotel_Hrefs.length);
		for (int i = 0; i < Hotel_Hrefs.length; i++) {

			System.out.println(i + 1 + ": " + Hotel_Hrefs[i]);
			driver.get(Hotel_Hrefs[i]);
			// To take a screenshot
			TakeScreenShot("Hotel + " + i);

		}
		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");

	}

	@AfterMethod(groups = { "Hotels", "Cruises" }) // AfterMethod annotation - This method executes after every test
													// execution
	public void screenShot(ITestResult result) {
		// using ITestResult.FAILURE is equals to result.getStatus then it enter into if
		// condition
		if (ITestResult.FAILURE == result.getStatus()) {
			try {
				// To create reference of TakesScreenshot
				TakesScreenshot screenshot = (TakesScreenshot) driver;
				// Call method to capture screenshot
				File src = screenshot.getScreenshotAs(OutputType.FILE);
				// Copy files to specific location
				// result.getName() will return name of test case so that screenshot name will
				// be same as test case name
				FileUtils.copyFile(src,
						new File(System.getProperty("user.dir") + "\\Error_Screenshots\\" + result.getName() + ".png"));
				System.out.println("Successfully captured a screenshot");
			} catch (Exception e) {
				System.out.println("Exception while taking screenshot " + e.getMessage());
			}
		}
	}

	@AfterSuite(groups = { "Basics", "SmokeTest" })
	public void CloseBrowser() {

		// To quit the browser
		driver.quit();

	}

}
