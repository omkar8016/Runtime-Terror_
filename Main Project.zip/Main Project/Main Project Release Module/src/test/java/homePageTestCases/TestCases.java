package homePageTestCases;

import org.testng.annotations.Test;

import setup.BaseClass;
import setup.LogIn;
import webPages.AddReleases;
import webPages.EditReleases;
import webPages.ReleasesPage;

public class TestCases extends BaseClass {

	// Screenshot screenShot = new Screenshot();
	/***************************************************************************/
	@Test(priority = 1)
	public void openBrowser() {
		try {
			LogIn.loadDriver();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/***************************************************************************/
	@Test(priority = 2)
	public void browseUrl() {
		LogIn.getURL();

	}

	/***************************************************************************/
	@Test(priority = 3)
	public void login() {
		LogIn.getCredentials();
	}

	/***************************************************************************/
	@Test(priority = 4)
	public void mainPage() {
		LogIn.getMainPage();
	
	}

	/***************************************************************************/
	@Test(priority = 5)
	public void openModule() {
		LogIn.openModule();
		
	}

	/***************************************************************************/
	@Test(priority = 6)
	public void releaseFunc() {
		ReleasesPage func = LogIn.nextPage();
		func.exportButton();
		func.clearAllFilters();
		func.multipleSort();
		func.downloadAttachments();
		func.searchBoxFilter();
		func.advancedFilter();
		func.tableViewFilter();

	}

	/***************************************************************************/
	@Test(priority = 7, dataProvider = "validInvalidData")
	public void saveButtonWithValidInvalidData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7, String col8, String col9, String col10, String col11) {
		AddReleases add = ReleasesPage.nextPage();

		add.addResources();
		add.switchFrame();
		add.nameTxtBox(col1);
		add.descTxtBox(col2);
		add.relType(col3);
		add.startDate(col4);
		add.endDate(col5);
		add.selectPriority(col6);
		add.selectTechnology(col7);
		add.setSize(col8);
		add.selectPerson(col9);
		add.relNum(col10);
		add.setCapacity(col11);
		add.clickOnSave();
		add.clickOnReturn();
		

	}

	/***************************************************************************/
	@Test(priority = 8, dataProvider = "mandatoryData")
	public void saveButtonWithMandatoryData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7) {
		AddReleases mand = ReleasesPage.nextPage();
		mand.addResources();
		mand.switchFrame();
		mand.nameTxtBox(col1);
		mand.descTxtBox(col2);
		mand.relType(col3);
		mand.startDate(col4);
		mand.endDate(col5);
		mand.selectPriority(col6);
		mand.selectTechnology(col7);
		mand.clickOnSave();
		mand.clickOnReturn();

	}

	/***************************************************************************/
	@Test(priority = 9, dataProvider = "modifiedData")
	public void saveButtonWithModifiedData(String col1, String col2, String col3, String col4, String col5, String col6,
			String col7, String col8, String col9, String col10, String col11) {
		EditReleases edit = AddReleases.nextPage();
		edit.parentFrame();
		edit.OpenRelease("REL8");
		edit.switchFrame();
		edit.getName().click();
		edit.getName().clear();
		edit.getName().sendKeys(col1);
		edit.getDescription().clear();
		edit.getDescription().sendKeys(col2);
		edit.relType(col3);
		edit.getStartDate().clear();
		edit.getStartDate().sendKeys(col4);
		edit.getEndDate().clear();
		edit.getEndDate().sendKeys(col5);
		edit.selectPriority(col6);
		edit.getSize().clear();
		edit.getSize().sendKeys(col8);
		edit.selectPerson(col9);
		edit.relNum().clear();
		edit.relNum().sendKeys(col10);
		edit.getCapacity().clear();
		edit.getCapacity().sendKeys(col11);
		edit.saveButton();
		edit.returnBackAfterCreation();

	}

	/***************************************************************************/

	@Test(priority = 10)
	public void saveButtonWithNullValues() {
		AddReleases rtn = ReleasesPage.nextPage();
		try {
			rtn.addResources();
			rtn.switchFrame();
			rtn.clickOnSave();
		} catch (NullPointerException e) {
		}
		rtn.clickOnReturn();
	}

	/***************************************************************************/
	@Test(priority = 11, dataProvider = "validInvalidData")
	public void returnButtonWithValidInvalidData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7, String col8, String col9, String col10, String col11) {
		AddReleases rtn = ReleasesPage.nextPage();
		rtn.addResources();
		rtn.switchFrame();
		rtn.nameTxtBox(col1);
		rtn.descTxtBox(col2);
		rtn.relType(col3);
		rtn.startDate(col4);
		rtn.endDate(col5);
		rtn.selectPriority(col6);
		rtn.selectTechnology(col7);
		rtn.setSize(col8);
		rtn.selectPerson(col9);
		rtn.relNum(col10);
		rtn.setCapacity(col11);
		rtn.clickOnReturn();

	}

	/***************************************************************************/
	@Test(priority = 12, dataProvider = "mandatoryData")
	public void returnButtonWithMandatoryData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7) {
		AddReleases mand = ReleasesPage.nextPage();
		mand.addResources();
		mand.switchFrame();
		mand.nameTxtBox(col1);
		mand.descTxtBox(col2);
		mand.relType(col3);
		mand.startDate(col4);
		mand.endDate(col5);
		mand.selectPriority(col6);
		mand.selectTechnology(col7);
		mand.clickOnReturn();
	}

	/***************************************************************************/
	@Test(priority = 13, dataProvider = "modifiedData")
	public void returnButtonWithModifiedData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7, String col8, String col9, String col10, String col11) {
		EditReleases edit = AddReleases.nextPage();
		edit.parentFrame();
		edit.OpenRelease("REL8");
		edit.switchFrame();
		edit.getName().click();
		edit.getName().clear();
		edit.getName().sendKeys(col1);
		edit.getDescription().clear();
		edit.getDescription().sendKeys(col2);
		edit.relType(col3);
		edit.getStartDate().clear();
		edit.getStartDate().sendKeys(col4);
		edit.getEndDate().clear();
		edit.getEndDate().sendKeys(col5);
		edit.selectPriority(col6);
		// edit.selectTechnology(col7);
		edit.getSize().clear();
		edit.getSize().sendKeys(col8);
		edit.selectPerson(col9);
		edit.relNum().clear();
		edit.relNum().sendKeys(col10);
		edit.getCapacity().clear();
		edit.getCapacity().sendKeys(col11);
		edit.saveButton();
		edit.returnBackAfterCreation();

	}

	/***************************************************************************/
	@Test(priority = 14)
	public void returnButtonWithNullValues() {
		AddReleases rtn = ReleasesPage.nextPage();
		rtn.addResources();
		rtn.switchFrame();
		rtn.clickOnReturn();
	}

	/***************************************************************************/
	@Test(priority = 15, dataProvider = "validInvalidData")
	public void saveAndAddNewButtonWithValidInvalidData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7, String col8, String col9, String col10, String col11) {
		AddReleases rtn = ReleasesPage.nextPage();
		rtn.addResources();
		rtn.switchFrame();
		rtn.nameTxtBox(col1);
		rtn.descTxtBox(col2);
		rtn.relType(col3);
		rtn.startDate(col4);
		rtn.endDate(col5);
		rtn.selectPriority(col6);
		rtn.selectTechnology(col7);
		rtn.setSize(col8);
		rtn.selectPerson(col9);
		rtn.relNum(col10);
		rtn.setCapacity(col11);
		rtn.clickOnSaveAddNew();
		rtn.clickOnReturn();

	}

	/***************************************************************************/
	@Test(priority = 16, dataProvider = "mandatoryData")
	public void saveAndAddNewButtonWithMandatoryData(String col1, String col2, String col3, String col4, String col5,
			String col6, String col7) {
		AddReleases mand = ReleasesPage.nextPage();
		mand.addResources();
		mand.switchFrame();
		mand.nameTxtBox(col1);
		mand.descTxtBox(col2);
		mand.relType(col3);
		mand.startDate(col4);
		mand.endDate(col5);
		mand.selectPriority(col6);
		mand.selectTechnology(col7);
		mand.clickOnSaveAddNew();
		mand.clickOnReturn();

	}

	/***************************************************************************/

	@Test(priority = 17)
	public void saveAndAddNewButtonWithNullValues() {
		AddReleases rtn = ReleasesPage.nextPage();
		try {
			rtn.addResources();
			rtn.switchFrame();
			rtn.clickOnSaveAddNew();
		} catch (NullPointerException e) {

		}
		rtn.clickOnReturn();
	}

	/***************************************************************************/
	@Test(priority = 18)
	public void returnButtonWithoutModificationInForm() {
		EditReleases edit = AddReleases.nextPage();
		edit.OpenRelease("REL8");
		edit.switchFrame();
		edit.returnBackAfterCreation();

	}

	/***************************************************************************/

	@Test(priority = 19)
	public void close() {
		LogIn.closeBrowser();
	}

}
