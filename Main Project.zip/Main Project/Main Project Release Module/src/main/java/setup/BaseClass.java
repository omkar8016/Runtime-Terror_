package setup;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class BaseClass {

	static final Logger logger = LogManager.getLogger("Releases Module");
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static WebDriver driver;
	
	@BeforeTest
	public void log() {
		// Logger logger=Logger.getLogger("BaseClass");

		PropertyConfigurator.configure("Log4j.properties");
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "\\HTML_Report\\ExtentReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Team Name", "RunTime Terror");
		extent.setSystemInfo("Project Name", "Releases Module");
		extent.setSystemInfo("Website Name", "mainspring");

		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("Releases Module HTML Report");
		htmlReporter.config().setReportName("Main Project Report");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.DARK);
		

	}

	@BeforeMethod
	public void extentReport(Method method) {
		String methodName = method.getName();
		test = extent.createTest(methodName);
		

	}

	/***************************************************************************/
	@AfterMethod

	public void getResult(ITestResult result, Method method) throws IOException {
		String methodName = method.getName();

		if (result.getStatus() == ITestResult.FAILURE) {
			logger.info(methodName + " Failed");
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " Test case FAILED due to below issues:",
					ExtentColor.RED));
			test.fail(result.getThrowable());
			try
			{
				TakesScreenshot screenshot=(TakesScreenshot)driver;
				File src=screenshot.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\Screenshots\\"+result.getName()+".png"));
			}
			catch (Exception e)
			{
				System.out.println("Exception while taking screenshot "+e.getMessage());
			} 
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			logger.info(methodName + " Passed");
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
		} else {
			logger.info(methodName + " Skipped");
			test.log(Status.SKIP,
					MarkupHelper.createLabel(result.getName() + " Test Case SKIPPED", ExtentColor.ORANGE));
			test.skip(result.getThrowable());
		}

	}

	@AfterSuite
	public void tearDown() {
		extent.flush();
	}

	/***************************************************************************/
	@DataProvider
	public Object[][] validInvalidData() {

		// public void ReadExcel() {
		ReadExcelDataFile readdata = new ReadExcelDataFile(
				System.getProperty("user.dir") + "\\mainResources\\InputFiles\\TcInput.xlsx");
		String sheetName = "Test Cases";
		String testName = "Test One";
		int startRowNum = 0;
		while (!readdata.getCellData(sheetName, 0, startRowNum).equalsIgnoreCase(testName)) {
			startRowNum++;
		}
		int startTestColumn = startRowNum + 1;
		int startTestRow = startRowNum + 2;

		// Find Number of Rows of TestCase
		int rows = 0;
		while (!readdata.getCellData(sheetName, 0, startTestRow + rows).equals("")) {
			rows++;
		}
		// System.out.println("Total Numbe of Rows in Test : " +testName + " is - "
		// +rows);

		// Find Number of Columns in Test
		int columns = 0;
		while (!readdata.getCellData(sheetName, columns, startTestColumn).equals("")) {
			columns++;
		}
		// Define two object array

		Object[][] dataSet = new Object[rows][columns];
		int dataRowNumber = 0;
		for (int rowNumber = startTestRow; rowNumber <= startTestColumn + rows; rowNumber++) {
			for (int colNumber = 0; colNumber < columns; colNumber++) {
				dataSet[dataRowNumber][colNumber] = readdata.getCellData(sheetName, colNumber, rowNumber);
			}
			dataRowNumber++;

		}
		return dataSet;

	}

	/***************************************************************************/
	@DataProvider
	public Object[][] mandatoryData() {

		// public void ReadExcel() {
		ReadExcelDataFile readdata = new ReadExcelDataFile(
				System.getProperty("user.dir") + "\\mainResources\\InputFiles\\TcInput.xlsx");
		String sheetName = "Test Cases";
		String testName = "Test Two";
		int startRowNum = 0;
		while (!readdata.getCellData(sheetName, 0, startRowNum).equalsIgnoreCase(testName)) {
			startRowNum++;
		}
		int startTestColumn = startRowNum + 1;
		int startTestRow = startRowNum + 2;

		// Find Number of Rows of TestCase
		int rows = 0;
		while (!readdata.getCellData(sheetName, 0, startTestRow + rows).equals("")) {
			rows++;
		}
		// System.out.println("Total Numbe of Rows in Test : " +testName + " is - "
		// +rows);

		// Find Number of Columns in Test
		int columns = 0;
		while (!readdata.getCellData(sheetName, columns, startTestColumn).equals("")) {
			columns++;
		}
		// Define two object array

		Object[][] dataSet = new Object[rows][columns];
		int dataRowNumber = 0;
		for (int rowNumber = startTestRow; rowNumber <= startTestColumn + rows; rowNumber++) {
			for (int colNumber = 0; colNumber < columns; colNumber++) {
				dataSet[dataRowNumber][colNumber] = readdata.getCellData(sheetName, colNumber, rowNumber);
			}
			dataRowNumber++;

		}
		return dataSet;

	}

	/***************************************************************************/
	@DataProvider
	public Object[][] modifiedData() {

		// public void ReadExcel() {
		ReadExcelDataFile readdata = new ReadExcelDataFile(
				System.getProperty("user.dir") + "\\mainResources\\InputFiles\\TcInput.xlsx");
		String sheetName = "Test Cases";
		String testName = "Test three";
		int startRowNum = 0;
		while (!readdata.getCellData(sheetName, 0, startRowNum).equalsIgnoreCase(testName)) {
			startRowNum++;
		}
		int startTestColumn = startRowNum + 1;
		int startTestRow = startRowNum + 2;

		// Find Number of Rows of TestCase
		int rows = 0;
		while (!readdata.getCellData(sheetName, 0, startTestRow + rows).equals("")) {
			rows++;
		}

		// Find Number of Columns in Test
		int columns = 0;
		while (!readdata.getCellData(sheetName, columns, startTestColumn).equals("")) {
			columns++;
		}
		// Define two object array

		Object[][] dataSet = new Object[rows][columns];
		int dataRowNumber = 0;
		for (int rowNumber = startTestRow; rowNumber <= startTestColumn + rows; rowNumber++) {
			for (int colNumber = 0; colNumber < columns; colNumber++) {
				dataSet[dataRowNumber][colNumber] = readdata.getCellData(sheetName, colNumber, rowNumber);
			}
			dataRowNumber++;

		}
		return dataSet;

	}

}
