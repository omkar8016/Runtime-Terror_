package webPages;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import setup.LoadProperties;

public class AddReleases {

	static WebDriver driver;
	Properties prop;
	WebDriverWait wait;
	String filePath = System.getProperty("user.dir") + "\\mainResources\\properties\\config.properties";

	public AddReleases() {

	}

	// Receiving the driver instance using consturctor
	public AddReleases(WebDriver driver) {
		
			AddReleases.driver = driver;
			prop = LoadProperties.readFile(filePath);
			wait = new WebDriverWait(driver, 10);

	}

	// coming back from iframe
	public void parentFrame() {
		driver.switchTo().defaultContent();
	}

	// Getting the values for given key from property file
	public String getPropertyValue(String key) {
		return LoadProperties.readProperty(key);
	}

	// locating the element
	public WebElement getElement(String path) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(path))));
		return driver.findElement(By.xpath(path));
	}

	public void sleep() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public void addResources() {

		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='KEY_BUTTON_Add-btnIconEl']")));
		driver.findElement(By.xpath("//span[@id='KEY_BUTTON_Add-btnIconEl']")).click();
	}

	public void addRe() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("AddRelBtn")).click();

	}

	public void nameTxtBox(String name) {
		WebElement Name = getElement(getPropertyValue("NameTxtBox"));
		Name.sendKeys(name);
	}

	public void descTxtBox(String desc) {
		// Provide Description of project
		WebElement description = getElement(getPropertyValue("DescriptionTxtBox"));
		description.sendKeys(desc);
	}

	public void relType(String Type) {
		// Select approxiamate release type
		Select s1 = new Select(getElement(getPropertyValue("releaseType")));

		s1.selectByVisibleText(Type);
	}

	public void startDate(String s_date) {
		// select the start date

		WebElement startdate = getElement(getPropertyValue("Startdate"));
		startdate.clear();
		startdate.sendKeys(s_date);
	}

	public void endDate(String e_date) {
		// Select Enddate
		WebElement endDate = getElement(getPropertyValue("Enddate"));
		endDate.sendKeys(e_date);
	}

	public void selectPriority(String priority) {
		// select the priority
		Select s2 = new Select(getElement(getPropertyValue("PriorityPath")));
		s2.selectByVisibleText(priority);
	}

	public void selectTechnology(String tech) {
		// select technology used
		try {
			Select s3 = new Select(getElement(getPropertyValue("techPath")));
			s3.selectByVisibleText(tech);
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	public void setSize(String size) {
		// Enter the size
		WebElement Size = getElement(getPropertyValue("SizeTxt"));
		Size.sendKeys(size);
	}

	public void selectPerson(String person) {
		// Select the person from the dropdown
		Select s4 = new Select(getElement(getPropertyValue("RespPath")));
		s4.selectByVisibleText(person);
	}

	public void relNum(String r_num) {
		// Enter the release number
		WebElement rel_num = getElement(getPropertyValue("ReleaseNum"));
		rel_num.sendKeys(r_num);
	}

	public void setCapacity(String capacity) {
		// Enter the capacity
		WebElement cap = getElement(getPropertyValue("CapacityTxt"));
		cap.sendKeys(capacity);
	}

	public void clickOnSave() {
		// save the details
		WebElement Save = getElement(getPropertyValue("SaveBtn"));
		Save.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}
	}

	public void clickOnSaveAddNew() {
		// save the details
		WebElement Save = getElement(getPropertyValue("saveAddNew"));
		Save.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);

		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert(); // System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}

	}

	public void clickOnReturn() {
		// save the details
		WebElement Rtn = getElement(getPropertyValue("ReturnBtn"));
		Rtn.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}
	}

	public void Return() {
		// save the details
		WebElement Rtn = getElement(getPropertyValue("ReturnBtn"));
		Rtn.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				// System.out.println(alert.getText());
				alert.accept();
			}
		} catch (Exception e) {

		}
		driver.switchTo().defaultContent();
	}

	// getting into frame
	public void switchFrame() {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.switchTo().frame("contentframe");

	}

	// navigating to next page
	public static EditReleases nextPage() {
		return PageFactory.initElements(driver, EditReleases.class);
	}

}
