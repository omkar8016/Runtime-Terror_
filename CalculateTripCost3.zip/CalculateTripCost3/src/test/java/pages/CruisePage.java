package pages;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.ReadJSON;
import Utilities.ReadPropertiesFile;
import Utilities.ReadXml;
import Utilities.Screenshot;
import Utilities.WriteCruiseDetails;
import Utilities.locators;

public class CruisePage {
	public static WebDriver driver;

	public CruisePage(WebDriver driver) {
		CruisePage.driver = driver;
	}

	/****************************************************************************************************/
	public void cruiseUrl() {
		String Base_Url = ReadPropertiesFile.getProperty("CruiseUrl");
		driver.navigate().to(Base_Url);
		Screenshot.TakeScreenShot(driver, "HomePageCruises");
		System.out.println("Now switching to Cruise Section");
	}
	/****************************************************************************************************/
	
	public void CruiseLine() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(locators.cruiseLine).click();
		driver.findElement(locators.selectCruiseLine).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String cruiseLine = ReadJSON.readJSONData("cruiseLine");
		//Thread.sleep(4000);
		
		System.out.println("CruiseLine chosen is: " + cruiseLine);
	}

	/****************************************************************************************************/
	public void CruiseShip() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.findElement(locators.cruiseShip).click();
		driver.findElement(locators.selectCruiseShip).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String cruiseShip =ReadXml.CruiseShipInput();
		Thread.sleep(4000);
		System.out.println("CruiseShip chosen is: " + cruiseShip);
	}

	/****************************************************************************************************/
	public void SearchCruise(WebDriver driver) throws InterruptedException {
		Thread.sleep(1000);
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.elementToBeClickable((locators.search)));
		driver.findElement(locators.search).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/****************************************************************************************************/
	// To write Passengers and Crew data in excel file
	public void cruiseDetails()
			throws IOException, InterruptedException {

		String parent = driver.getWindowHandle();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		WriteCruiseDetails excel = new WriteCruiseDetails();
		

		
		  Set<String> s = driver.getWindowHandles(); for (String element : s) { if
		  (!parent.equals(element)) { driver.switchTo().window(element); } }
		 
		jse.executeScript("window.scrollBy(0,350)");

		WebElement passenger = driver.findElement(locators.passengerAndCrew);
		System.out.println(passenger.getText());
		//Thread.sleep(3000);
		excel.writeToExcel(driver.findElement(locators.PassengerAndCrew).getText(), 0);
		
		
		WebElement launch = driver.findElement(locators.launchYear);
		System.out.println(launch.getText() + "\n");
		excel.writeToExcel(driver.findElement(locators.launchYear).getText(),1);
		
		
		List<WebElement> list = driver.findElements(locators.languageList);
		int i=2;
        for (WebElement element : list) 
        {
            excel.writeToExcel(element.getText(),i);
            System.out.println(element.getText());
            i++;
        }
        System.out.println("\n");
		
		 
	}

	/****************************************************************************************************/
	/*
	 * public void launchedYear() throws IOException { String parent =
	 * driver.getWindowHandle(); JavascriptExecutor jse = (JavascriptExecutor)
	 * driver; WriteCruiseDetails excel = new WriteCruiseDetails();
	 * 
	 * 
	 * 
	 * 
	 * Set<String> s = driver.getWindowHandles(); for (String element : s) { if
	 * (!parent.equals(element)) { driver.switchTo().window(element); } }
	 * 
	 * 
	 * jse.executeScript("window.scrollBy(0,350)");
	 * 
	 * WebElement launch = driver.findElement(locators.launchYear);
	 * System.out.println(launch.getText() + "\n");
	 * 
	 * excel.writeToExcel(driver.findElement(locators.launchYear).getText(),1); }
	 */

	/**
	 * @throws InterruptedException **************************************************************************************************/
	// To write Languages in excel file
	/*
	 * public void languages() throws IOException, InterruptedException {
	 * 
	 * String parent = driver.getWindowHandle(); JavascriptExecutor jse =
	 * (JavascriptExecutor) driver; WriteCruiseDetails excel = new
	 * WriteCruiseDetails();
	 * 
	 * Set<String> s = driver.getWindowHandles(); for (String element : s) { if
	 * (!parent.equals(element)) { driver.switchTo().window(element); } }
	 * 
	 * 
	 * jse.executeScript("window.scrollBy(0,350)"); Thread.sleep(3000);
	 * 
	 * List<WebElement> list = driver.findElements(locators.languageList);
	 * System.out.println("Excel started");
	 * 
	 * for (WebElement element : list) { excel.writeToExcel(element.getText(),2);
	 * System.out.println(element.getText()); } System.out.println("Excel ended");
	 * System.out.println("\n");
	 * 
	 * }
	 */
	/****************************************************************************************************/
	public void printingInExcel() {
		
	}
	
	/****************************************************************************************************/
	
	public void BackToHomePage() {
		
		  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		  WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(locators.homePage));
		  wait.until(ExpectedConditions.elementToBeClickable(locators.homePage));
		 
		driver.findElement(locators.homePage).click();
		
	}

}
