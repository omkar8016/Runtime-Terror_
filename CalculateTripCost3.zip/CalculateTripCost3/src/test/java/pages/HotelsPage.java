package pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.ReadPropertiesFile;
import Utilities.ReadUserDetails;
import Utilities.Screenshot;
import Utilities.locators;

public class HotelsPage {
	static WebDriver driver;

	public HotelsPage(WebDriver driver) {
		HotelsPage.driver = driver;
	}

	/****************************************************************************************************/
	// This function is used to read the property file
	public static String getPropertyFile(String prop_name) throws IOException {
		Properties prop = new Properties();
		InputStream input = new FileInputStream(System.getProperty("user.dir") + "\\Config.properties");
		prop.load(input);
		return prop.getProperty(prop_name);
	}

	/****************************************************************************************************/

	public void hotelUrl() {
		String Base_Url = ReadPropertiesFile.getProperty("HotelUrl");
		driver.navigate().to(Base_Url);
		Screenshot.TakeScreenShot(driver, "HomePage");

	}

	/****************************************************************************************************/
	public void SearchDest() throws IOException {

		Properties prop = new Properties();
		InputStream input = new FileInputStream(System.getProperty("user.dir") + "\\Config.properties");
		prop.load(input);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		driver.findElement(locators.searchButton).click();
		ReadUserDetails detail = new ReadUserDetails();
		String Location = detail.ReadDestination();
		driver.findElements(locators.searchResult2).get(1).sendKeys(Location);
		jse.executeScript("window.scrollBy(0,350)");
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locators.searchSuggest));
		WebElement Parent = driver.findElement(locators.searchSuggestion);
		Screenshot.TakeScreenShot(driver, "Search_Suggestions");
		List<WebElement> Search_Suggestions = new ArrayList<WebElement>();
		Search_Suggestions = Parent.findElements(By.tagName("a"));
		int temp = 0;

		for (int i = 0; i < Search_Suggestions.size(); i++) {

			String title = Search_Suggestions.get(i).getAttribute("href");
			System.out.println(title);

			try {
				if (Search_Suggestions.get(i).getAttribute("href")
						.equalsIgnoreCase("https://www.tripadvisor.in/Tourism-g294207-Nairobi-Vacations.html")) {
					temp = i;
					break;
				}
			} catch (Exception e) {
				System.out.println("Search-Suggestions Not available");
				driver.get("https://www.tripadvisor.in/Tourism-g294207-Nairobi-Vacations.html");
			}
		}

		driver.get(Search_Suggestions.get(temp).getAttribute("href"));
		System.out.println("Destination is: " + Location + "\n");

	}

	/****************************************************************************************************/

	public void clickHolidayHomes() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locators.holidayHomes));
		wait.until(ExpectedConditions.elementToBeClickable(locators.holidayHomes));
		// Thread.sleep(5000);

		WebElement Holiday_homes = driver.findElement(locators.holidayHomes);
		Actions actions = new Actions(driver);
		actions.moveToElement(Holiday_homes).doubleClick().build().perform();
		Screenshot.TakeScreenShot(driver, "HolidayHomes");
	}

	/****************************************************************************************************/
	//This function is used to parse the data from Excel File
	public static String parseDate(String dates) {
		//Replacing all hiphens with space
		String date = dates.replaceAll("-", " ");
		
		return date;
	}
	/****************************************************************************************************/
	
	
	public void checkInDate() throws IOException, InterruptedException {
		String[] Dates = new String[1];
		Dates = ReadUserDetails.ReadDates();
		String check_in = Dates[0];
		String parsed_Check_in = parseDate(check_in);
		
		driver.findElements(By.cssSelector(".lRYY2wxe")).get(0).click();
		
		Thread.sleep(500);
		Screenshot.TakeScreenShot(driver, "Check_in");
		WebDriverWait wait=new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@aria-label,'"+parsed_Check_in+"')]")));
		driver.findElement(By.xpath("//div[contains(@aria-label,'"+parsed_Check_in+"')]")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Check-in Date is : " + check_in);
	}

	/****************************************************************************************************/

	public void checkOutDate() throws IOException, InterruptedException {
		String[] Dates = new String[1];
		Dates = ReadUserDetails.ReadDates();
		String check_out = Dates[1];
		String parsed_Check_out = parseDate(check_out);
		
		Thread.sleep(500);
		Screenshot.TakeScreenShot(driver ,"Check_out");
		WebDriverWait wait=new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@aria-label,'"+parsed_Check_out+"')]")));
		driver.findElement(By.xpath("//div[contains(@aria-label,'"+parsed_Check_out+"')]")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Check-out Date is: " + check_out);

	}

	/****************************************************************************************************/
	public void guests() throws IOException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(locators.guest).click();
		int number_of_guests = ReadUserDetails.ReadNumberOfGuest();

		for (int defvalue = 2; defvalue < number_of_guests; defvalue++) {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(locators.guestAdd).click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
		Screenshot.TakeScreenShot(driver, "NoOfGuest");

		driver.findElement(locators.apply).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Number of guests to book Holiday Homes is :  " + number_of_guests + "\n");
	}

	/****************************************************************************************************/

	public void sortBy() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 120);
		 * 
		 * wait.until(ExpectedConditions.visibilityOfElementLocated(sortRate));
		 * wait.until(ExpectedConditions.elementToBeClickable(sortRate));
		 */
		Thread.sleep(5000);

		// driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(locators.sortRate)).click().perform();

		System.out.println("Values in sort by are: ");
		List<WebElement> list = driver.findElements(locators.sortByValues);
		for (int i = 0; i < list.size(); i++) {
			WebElement element = list.get(i);
			String value = element.getAttribute("innerHTML");
			System.out.println(i + 1 + ". " + value);
		}
		Screenshot.TakeScreenShot(driver, "Sort By Values");
	}

	/****************************************************************************************************/
	public void travellerRatings() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(locators.travellerRating).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Screenshot.TakeScreenShot(driver, "Traveler Sort");

		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");
	}

	/****************************************************************************************************/
	public void show() {
		// Selecting Elevator/Lift access in amenities
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1100)");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(locators.amenities).click();
		Screenshot.TakeScreenShot(driver, "Show More");

	}

	/****************************************************************************************************/

	public void selectLift() throws InterruptedException {
		driver.findElement(locators.liftFacility).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Screenshot.TakeScreenShot(driver, "Lift Access");

		js.executeScript("window.scrollBy(0,-900)");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// To sync the code
		Thread.sleep(1000);
	}

	/****************************************************************************************************/
	// This function is used to fetch the Hotel Names
	public static String[] GetHotelName(WebDriver driver) throws IOException {
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.visibilityOfElementLocated(locators.searchResult));
		wait.until(ExpectedConditions.elementToBeClickable(locators.searchResult));

		Screenshot.TakeScreenShot(driver, "Search Results");

		List<WebElement> Hotel_Names = new ArrayList<WebElement>();

		WebElement Parent = driver.findElement(locators.hotelParent);
		Hotel_Names = Parent.findElements(locators.hotelName);

		String[] HotelName = new String[3];

		System.out.println("Hotel Names are-    ");
		for (int i = 0; i < 3; i++) {
			// Storing hotel names inside our array
			HotelName[i] = Hotel_Names.get(i).getText();
			System.out.println(Hotel_Names.get(i).getText());
		}

		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");
		return HotelName;
	}

	/****************************************************************************************************/
	// This function is used to fetch the Total Hotel Charges
	public static String[] GetHotelTotalCharge(WebDriver driver) throws IOException {
		List<WebElement> Total_Charges = new ArrayList<WebElement>();

		// Getting the parent WebElement of all the search results

		WebElement Parent = driver.findElement(locators.hotelParent);
		Total_Charges = Parent.findElements(locators.hotelTotelCharges);

		// Creating a String array to store the Total Charges of the First 3 Search
		// Results
		String[] TotalCharge = new String[3];
		// To print to console
		System.out.println("Total charges are:----     ");
		for (int i = 0; i < 3; i++) {
			// Storing hotel names inside our array
			TotalCharge[i] = Total_Charges.get(i).getText();
			System.out.println(i + 1 + TotalCharge[i]);
		}
		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");
		return TotalCharge;
	}

	/****************************************************************************************************/
	// This function is to fetch the Hotel Charges per night
	public static String[] GetChargesPerNight(WebDriver driver) throws IOException {
		List<WebElement> ChargesPerNight = new ArrayList<WebElement>();

		// Getting the parent WebElement of all the search results

		WebElement Parent = driver.findElement(locators.hotelParent);

		ChargesPerNight = Parent.findElements(locators.hotelPerNightCharge);

		// To print to console
		System.out.println("Charges per night are:----     ");
		// Creating a String array to store the Charges per Night of the First 3 Search
		// Results
		String[] TotalCharge = new String[3];
		for (int i = 0; i < 3; i++) {

			// Storing hotel names inside our array
			TotalCharge[i] = ChargesPerNight.get(i).getText();
			System.out.println(i + 1 + TotalCharge[i]);
		}
		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");
		return TotalCharge;
	}

	/****************************************************************************************************/

	public void hotelScreenShot() throws IOException, InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		String[] Hotel_Hrefs = new String[3];
		Hotel_Hrefs = HotelsPage.GetHotelLinks(driver);
		System.out.println("Size is :" + Hotel_Hrefs.length);
		for (int i = 0; i < Hotel_Hrefs.length; i++) {

			System.out.println(i + 1 + ". " + Hotel_Hrefs[i]);
			driver.get(Hotel_Hrefs[i]);
			Screenshot.TakeScreenShot(driver, "Hotel + " + i);

		}
		System.out.println(
				"---------------------------------------------------------------------------------------------------------------");
	}

	/****************************************************************************************************/

	// This function is to get the Hotel Hrefs
	public static String[] GetHotelLinks(WebDriver driver) throws IOException, InterruptedException {
		List<WebElement> Hrefs = new ArrayList<WebElement>();
		WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.visibilityOfElementLocated(locators.searchResult1));
		wait.until(ExpectedConditions.elementToBeClickable(locators.searchResult1));
		Thread.sleep(500);

		// Getting the parent WebElement of all the search results
		WebElement Parent = driver.findElement(locators.hotelParent);

		Hrefs = Parent.findElements(locators.hotelName1);

		String[] Href = new String[3];
		for (int i = 0; i < 3; i++) {

			Href[i] = Hrefs.get(i).getAttribute("href");

		}
		return Href;
	}

}
