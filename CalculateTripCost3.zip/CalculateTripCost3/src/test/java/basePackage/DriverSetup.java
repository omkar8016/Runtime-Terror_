package basePackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import Utilities.ReadPropertiesFile;

public class DriverSetup {
	WebDriver driver;
	static String path = System.getProperty("user.dir");

	// This Function is used to setup Chrome Driver
	public static WebDriver setupChromeDriver(WebDriver driver) {
		// Here, we are using path to get the home directory of the user to setup our
		// webdriver.

		System.setProperty("webdriver.chrome.driver", path + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		return driver;
	}

	// This Function is used to setup FireFox Driver
	public static WebDriver setupFireFoxDriver(WebDriver driver) {
		// Here, we are using path to get the home directory of the user to setup our
		// webdriver.

		System.setProperty("webdriver.gecko.driver", path + "\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		return driver;
	}

	// This Function is used to setup Opera Driver
	public static WebDriver setupEdgeDriver(WebDriver driver) {
		// Here, we are using path to get the home directory of the user to setup our
		// webdriver.

		System.setProperty("webdriver.edge.driver", path + "\\Drivers\\msedgedriver.exe");
		driver = new EdgeDriver();
		return driver;
	}

	public static WebDriver openBrowser(WebDriver driver) {
		// Setting up the driver for chosen browser from properties file
		if (ReadPropertiesFile.getProperty("Browser").equalsIgnoreCase("Chrome")) {
			driver = setupChromeDriver(driver);

		} else if (ReadPropertiesFile.getProperty("Browser").equalsIgnoreCase("FireFox")) {
			driver = setupFireFoxDriver(driver);

		} else if (ReadPropertiesFile.getProperty("Browser").equalsIgnoreCase("Edge")) {
			driver = setupEdgeDriver(driver);

		} else {
			driver = setupChromeDriver(driver);
		}
		driver.manage().window().maximize(); // maximizes window
		driver.manage().deleteAllCookies(); // delete cookies


		return driver;
	}

	
}
