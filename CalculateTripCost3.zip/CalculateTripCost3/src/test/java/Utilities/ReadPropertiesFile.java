package Utilities;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class ReadPropertiesFile {
	WebDriver driver;

	public ReadPropertiesFile(WebDriver driver) {
		this.driver = driver;
	}

	// This function is used to read the property file
	public static String getProperty(String prop_name) {
		Properties prop = new Properties();
		try {

			// Importing the config file
			InputStream readFile;

			readFile = new FileInputStream(System.getProperty("user.dir") + "\\Config.properties");
			// Loading the config file
			prop.load(readFile);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop.getProperty(prop_name);

	}

}
