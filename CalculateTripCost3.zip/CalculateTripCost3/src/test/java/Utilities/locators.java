package Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class locators {

	public static WebDriver driver;

	public static By searchResult = By.xpath("//a[normalize-space()='Elegant Cosy Conquest']");
	public static By hotelName = By.cssSelector("._2K0y-IXo");
	public static By holidayHomes = By.partialLinkText("Holiday Homes");
	public static By sortRate = By.xpath("(//div[@class=\"_1NO-LVmX\"])[3]");
	public static By travellerRating = By.xpath("//span[contains(text(),'Traveller Rating')]");
	public static By guest = By.className("_2uJXqhFj");
	public static By guestAdd = By.xpath("(//span[@class=\"ui_icon plus HxR7KwIa\"])[2]");
	public static By apply = By.xpath("(//button[@class=\"ui_button primary fullwidth\"])[2]");
	public static By amenities = By.cssSelector(
			"#component_2 > div > div.delineation > div > div._3gJTNtfw > div._3PlsTJV5 > div._3b6IjZ6r > div > div > div:nth-child(12) > div._3kI1z_wP > span._3ncH7U-p");
	public static By liftFacility = By.xpath("//div[contains(text(),'Elevator/Lift access')]");
	public static By sortByValues = By
			.xpath("//*[@id=\"component_2\"]/div/div[3]/div/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div/span");

	/********************************** Hotels *********************************/
	public static By hotelParent = By.className("_3uQcWelb");
	public static By hotelName1 = By.xpath("//h2[contains(@class='_2K0y-IXo', '')]/a");
	public static By searchResult1 = By.xpath("//a[normalize-space()='Elegant Cosy Conquest']");
	public static By hotelTotelCharges = By.className("_3f9mHAKH");
	public static By hotelPerNightCharge = By.className("_33TIi_t4");

	/********************************** Hotels *********************************/
	public static By searchButton = By.xpath("(//input[@class=\"_3qLQ-U8m\"])[2]");
	public static By searchResult2 = By.cssSelector("._3qLQ-U8m");
	public static By searchSuggest = By.xpath("//a[@class='_1c2ocG0l' and contains(., 'Nairobi')]");
	public static By searchSuggestion = By.className("_27pk-lCQ");

	/********************************** Hotels *********************************/
	public static By passengerAndCrew = By.xpath("//*[@id=\"ship_overview\"]/div/div/div/div[1]/div[1]/div[2]/div[1]");

	public static By PassengerAndCrew = By.cssSelector(
			"#ship_overview > div > div > div > div.ui_column.is-6-desktop.is-12-mobile.is-12-tablet._2uUROZdb > div.ui_column.is-12-desktop.is-12-mobile.is-12-tablet._114pqgnv > div._30ZCn9lR > div:nth-child(1)");

	public static By launchYear = By.xpath("//*[contains(text(),\"Launched: 2\")]");
	public static By languageList = By.xpath("//*[@id=\"ship_reviews\"]//label/span[1]");
	public static By LanguageList = By.cssSelector("span[class='_1wk-I7LS']");

	/********************************** Hotels *********************************/
	public static By cruiseLine = By.xpath("//*[@id=\"component_1\"]/div/div[3]/div/div[1]/div/button");
	public static By selectCruiseLine = By.xpath("//*[@id=\"menu-item-17391496\"]");
	public static By cruiseShip = By.xpath("//*[@id=\"component_1\"]/div/div[3]/div/div[2]/div/button");
	public static By selectCruiseShip = By.xpath("//*[@id=\"menu-item-15691210\"]/span");
	public static By search = By.cssSelector("span._2O1ErRJV:nth-child(1) > button");

	//public static By homePage = By.xpath("//*[@id=\"component_7\"]/div[2]/div[2]/header/div/nav/a/img");
	public static By homePage = By.cssSelector("#component_7 > div.o8RP7jPq > div._10GLY_Cl > header > div > nav > a > img");
}
