package TestCases;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Utilities.WriteHotelDetails;
import basePackage.DriverSetup;
import pages.CruisePage;
import pages.HotelsPage;

public class CalculateTripCost {

	public static WebDriver driver;

	@BeforeSuite(groups = { "Basics", "SmokeTest" })
	// This function is used to initialize the drivers.
	public void SetDrivers() throws IOException {

		driver = DriverSetup.openBrowser(driver);

	}

	@Test(priority = 1, groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// This test is to set the Url of the Hotels
	public void SetHotelsUrl() throws IOException {

		HotelsPage hp = new HotelsPage(driver);
		hp.hotelUrl();

	}

	@Test(priority = 2, groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// This test is to search the Destination
	public void SearchDestination() throws IOException, InterruptedException {

		HotelsPage hp = new HotelsPage(driver);
		hp.SearchDest();

	}

	@Test(priority = 3, dependsOnMethods = "SearchDestination", groups = { "Hotels", "RegressionTest", "SmokeTest" })
	// This Test is to Click on the Holiday Homes Button
	public void ClickHolidayHomesButton() throws InterruptedException {

		HotelsPage hp = new HotelsPage(driver);
		hp.clickHolidayHomes();

	}

	@Test(priority = 4, groups = { "Hotels", "RegressionTest" })
	// To set the Check-in Dates
	public void SetCheckInDate() throws IOException, InterruptedException {

		HotelsPage hp = new HotelsPage(driver);
		hp.checkInDate();

	}

	@Test(priority = 5, groups = { "Hotels", "RegressionTest" })
	// To set the Check-out Dates
	public void SetCheckOutDate() throws IOException, InterruptedException {

		HotelsPage hp = new HotelsPage(driver);
		hp.checkOutDate();
	}

	@Test(priority = 6, groups = { "Hotels", "RegressionTest" })
	// To select the Number of Guests
	public void NoOfGuests() throws Exception {

		HotelsPage hp = new HotelsPage(driver);
		hp.guests();

	}

	@Test(priority = 7, groups = { "Hotels", "RegressionTest" })
	// To sort the results by Traveler Ratings
	public void SortByValues() throws Exception {

		HotelsPage hp = new HotelsPage(driver);
		hp.sortBy();

	}

	@Test(priority = 8, groups = { "Hotels", "RegressionTest" })
	// To sort the results by Traveler Ratings
	public void SortByTraveller() {
		HotelsPage hp = new HotelsPage(driver);
		hp.travellerRatings();

	}

	@Test(priority = 9, groups = { "Hotels", "RegressionTest" })
	// To click on LiftAaccess
	public void ShowMore() throws Exception {
		HotelsPage hp = new HotelsPage(driver);
		hp.show();

	}

	@Test(priority = 10, groups = { "Hotels", "RegressionTest" })
	// To click on LiftAaccess
	public void LiftAccess() throws Exception {
		HotelsPage hp = new HotelsPage(driver);
		hp.selectLift();
	}

	@Test(priority = 11, groups = { "Hotels", "RegressionTest" })
	// To get all the required details of the top-3 result hotels
	public void HotelDetails() throws IOException, InterruptedException {

		// To store the Hotel Names
		String[] Hotel_Name = new String[3];
		Hotel_Name = HotelsPage.GetHotelName(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// To store the total amount
		String[] total_amount = new String[3];
		total_amount = HotelsPage.GetHotelTotalCharge(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// To store the charges per night
		String[] charges_pernight = new String[3];
		charges_pernight = HotelsPage.GetChargesPerNight(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		WriteHotelDetails.WriteToExcel(Hotel_Name, total_amount, charges_pernight);

	}

	@Test(priority = 12, groups = { "Hotels", "RegressionTest" })
	// To get the screenshots of the 3 respective Hotels
	public void GetHotelScreenShots() throws IOException, InterruptedException {

		HotelsPage hp = new HotelsPage(driver);
		hp.hotelScreenShot();
	}

	@Test(priority = 13, groups = { "Cruises", "RegressionTest", "SmokeTest" })
	// This function is to set the url of Cruises
	public static void SetCruiseUrl() throws IOException {
		CruisePage cp = new CruisePage(driver);
		cp.cruiseUrl();
	}

	@Test(priority = 14, groups = { "Cruises", "RegressionTest" })
	// To set the Cruise Ship and Cruise Line
	public void SetCruiseLine() throws IOException, InterruptedException {

		CruisePage cp = new CruisePage(driver);
		cp.CruiseLine();

	}

	@Test(priority = 15, groups = { "Cruises", "RegressionTest" })
	// To set the Cruise Ship and Cruise Line
	public void SetCruiseShip() throws IOException, InterruptedException {

		CruisePage cp = new CruisePage(driver);
		cp.CruiseShip();

	}

	@Test(priority = 16, groups = { "Cruises", "RegressionTest" })
	public void clickSearch() throws InterruptedException {

		CruisePage cp = new CruisePage(driver);
		cp.SearchCruise(driver);

	}

	@Test(priority = 17, groups = { "Cruises", "RegressionTest" })
	// To get the Cruise Details
	public void GetCruiseDetails() throws IOException, InterruptedException {

		CruisePage cp = new CruisePage(driver);
		cp.cruiseDetails();

	}

	@Test(priority = 18, groups = { "Cruises", "RegressionTest" })
	// To get the Cruise Details
	public void NavigateHomepage() throws IOException, InterruptedException {

		CruisePage cp = new CruisePage(driver);
		cp.BackToHomePage();
		System.out.println("Homepage worked");
		Thread.sleep(3000);

	}

	@AfterMethod(groups = { "Hotels", "Cruises" })
	// AfterMethod annotation - This method executes after every test execution

	public void screenShot(ITestResult result) {

		if (ITestResult.FAILURE == result.getStatus()) {
			try {
				TakesScreenshot screenshot = (TakesScreenshot) driver;
				File src = screenshot.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(src,
						new File(System.getProperty("user.dir") + "\\Error_Screenshots\\" + result.getName() + ".png"));
				System.out.println("Successfully captured a screenshot");
			} catch (Exception e) {
				System.out.println("Exception while taking screenshot " + e.getMessage());
			}
		}
	}

	@AfterSuite(groups = { "Basics", "SmokeTest" })
	public void CloseBrowser() {

		// To quit the browser
		driver.quit();

	}

}
