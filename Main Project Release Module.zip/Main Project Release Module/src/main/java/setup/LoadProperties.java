package setup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoadProperties {

	public static String readProperty(String key) {
		
		String out = null;
		Properties props = new Properties();
		FileInputStream readFile=null;
		File file=new File(".\\mainResources\\properties\\config.properties");
		try{
			readFile= new FileInputStream(file);
			
			props.load(readFile);
						
			out= props.getProperty(key);
			 

			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		
		return out;
		
		
	}

	
	  public static Properties readFile(String filePath) { 
		  return null;
		 }
	 
}
